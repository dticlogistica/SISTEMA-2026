
// URL do Google Apps Script (Web App)
// Passo a passo:
// 1. No Google Sheets, vá em Extensões > Apps Script
// 2. Cole o código backend fornecido
// 3. Clique em Implantar > Nova Implantação > Web App > Acesso: "Qualquer pessoa"
// 4. Cole a URL gerada abaixo:

export const API_URL = 'https://script.google.com/macros/s/AKfycbyNLt5pNZO-pP2JTLUZLEuITSTz-7VZYRhhx6g3u0UXYYRZbolRTC2rLzxyJq5sjuFn0g/exec';
