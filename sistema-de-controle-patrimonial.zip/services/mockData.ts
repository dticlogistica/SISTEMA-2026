
// Este arquivo não é mais utilizado pois o sistema está conectado ao Google Sheets.
// Mantido apenas para referência de tipagem se necessário.
import { User, UserRole } from '../types';

export const MOCK_USERS: User[] = [];
export const MOCK_NES = [];
export const MOCK_PRODUCTS = [];
export const MOCK_MOVEMENTS = [];
